package group2.edy.RoadMaintenance;


import java.util.Date;

public class Account {
    public int id;
    public String history;
    public Date opened;

    public void create(int _id, String _history, Date _opened){
        id = _id;
        history = _history;
        opened = _opened;
    }

    public void modify(int _id, String _history, Date _opened){
        id = _id;
        history = _history;
        opened = _opened;
    }

    public void delete(){
        id = -1;
        history = "$deleted";
    }
}