package group2.edy.RoadMaintenance;


import java.util.HashMap;

public class CEO extends Worker {
    public HashMap<String, Worker> employees = new HashMap<String, Worker>();

    public CEO(){
        super();
    }

    public CEO(String _name, String _address, int _age, int _salary, String _position ){
        super(_name, _address,_age, _salary, _position );
    }

    public void addWorker(Worker newWorker){
        employees.put(newWorker.name, newWorker);
    }

    public void removeWorker(Worker worker){
        employees.remove(worker.name);
    }

    public void changeSalary(String name, int newSalary){
        Worker tmp = employees.get(name);
        tmp.changeSalary(newSalary);
        employees.remove(name);
        employees.put(tmp.name, tmp);
    }

    public void changePosition(String name, String newPosition){
        Worker tmp = employees.get(name);
        tmp.changePosition(newPosition);
        employees.remove(name);
        employees.put(tmp.name, tmp);
    }

    public void passEmployeesToNewCEO(CEO newCEO){
        newCEO.employees = employees;
    }
}
