package group2.edy.RoadMaintenance;


public class Worker {
    public String name;
    private String address;
    private int age;
    private int salary;
    private String position;
    private int hours;

    Worker(){

    }

    Worker(String _name, String _address, int _age, int _salary, String _position ){
        name = _name;
        address = _address;
        age = _age;
        salary = _salary;
        position = _position;
        hours = 0;
    }

    public void addShift(int workedHours){
        hours = hours + workedHours;
    }

    public void hasBirthday(){
        age++;
    }

    public void changeSalary(int newSalary){
        salary = newSalary;
    }

    public void changePosition(String newPosition){
        position = newPosition;
    }

    public void changeAddress(String newAddress){
        address = newAddress;
    }
}
